package com.digitalhouse.aula5;

import com.digitalhouse.aula5.model.User;
import com.digitalhouse.aula5.service.IDownload;
import com.digitalhouse.aula5.service.impl.DownloadProxy;
import com.digitalhouse.aula5.service.impl.DownloadService;

public class Main {

    public static void main(String[] args) {

    User user = new User("Premium");

    IDownload proxy = new DownloadProxy(new DownloadService());

    proxy.fazerDownload(user);


    }
}
