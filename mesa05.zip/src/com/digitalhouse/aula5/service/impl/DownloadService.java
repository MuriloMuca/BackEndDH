package com.digitalhouse.aula5.service.impl;

import com.digitalhouse.aula5.model.User;
import com.digitalhouse.aula5.service.IDownload;

public class DownloadService implements IDownload {
    @Override
    public void fazerDownload(User user) {
        System.out.println("Download Feito com sucesso");
    }
}
