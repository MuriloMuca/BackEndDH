package com.digitalhouse.aula5.service;

import com.digitalhouse.aula5.model.User;

public interface IDownload {

    public void fazerDownload(User user);
}
