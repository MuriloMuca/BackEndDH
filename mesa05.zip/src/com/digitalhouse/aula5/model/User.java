package com.digitalhouse.aula5.model;

public class User {
    private String plano;

    public User(String plano) {
        this.plano = plano;
    }

    public String getPlano() {
        return plano;
    }

    public void setPlano(String plano) {
        this.plano = plano;
    }
}
