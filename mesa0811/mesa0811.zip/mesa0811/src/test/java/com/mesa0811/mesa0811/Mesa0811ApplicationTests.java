package com.mesa0811.mesa0811;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mesa0811ApplicationTests {

	@Test
	void contextLoads() {
	}

}
