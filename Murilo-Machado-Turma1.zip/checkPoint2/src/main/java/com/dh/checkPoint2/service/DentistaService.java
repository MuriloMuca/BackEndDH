package com.dh.checkPoint2.service;
import com.dh.checkpoint2.persistance.model.Dentista;
import com.dh.checkpoint2.persistance.repository.DentistaRepository;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DentistaService {

    private final Logger loggerDentista = Logger.getLogger(DentistaService.class.getName());

    @Autowired
    private DentistaRepository dentistaRepository;

    public DentistaService() {
        PropertyConfigurator.configure("log4j.properties");
    }

    public Dentista inserirDentista(Dentista dent){
        try {
            return dentistaRepository.save(dent);
        } catch(Exception exc){
            loggerDentista.error("Erro ao inserir um novo dentista");
            return null;
        }
    }

    public void deletarDentista(Integer id){
        try {
            dentistaRepository.deleteById(id);
        } catch(Exception exc){
            loggerDentista.error("Erro ao deletar dentista de id:" + id);
        }
    }

    public List<Dentista> selecionarDentistas(){
        try{
            return dentistaRepository.findAll();
        } catch(Exception exc){
            loggerDentista.error("Erro ao selecionar todos os dentistas");
            return null;
        }
    }

    public Dentista buscarDentistaId(Integer id){
        try {
            return dentistaRepository.findById(id).get();
        } catch(Exception exc){
            loggerDentista.error("Erro ao buscar o dentista pelo id " + id);
            return null;
        }
    }

    public Dentista  atualizarDentista(Dentista dent){
        try {
            Dentista dentista = dentistaRepository.getById(dent.getId());
            dentista.setNome(dent.getNome());
            dentista.setSobrenome(dent.getSobrenome());

            return dentistaRepository.save(dentista);
        } catch(Exception exc){
            loggerDentista.error("Erro ao atualizar as informações do dentista.");
            return null;
        }
    }
}