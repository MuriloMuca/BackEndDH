package com.dh.checkpoint2.persistance.model;

import javax.persistence.*;

@Table @Entity
public class Paciente {

    @Id
    @SequenceGenerator(name = "paciente_sequencia", sequenceName = "paciente_sequencia", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "paciente_sequencia")
    private Integer id;
    private String nome;
    private String sobrenome;
    private String email;

    public Paciente(String nome, String sobrenome, String email) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.email = email;
    }

    public Paciente() {}

    public Integer getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public String getEmail() {
        return email;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
