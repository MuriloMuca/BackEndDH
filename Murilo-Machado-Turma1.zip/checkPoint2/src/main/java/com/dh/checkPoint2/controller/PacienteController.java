package com.dh.checkpoint2.controller;
import com.dh.checkpoint2.persistance.model.Paciente;
import com.dh.checkpoint2.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("paciente")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @PostMapping
    public ResponseEntity<Paciente> inserirPaciente(@RequestBody Paciente pac) {
        return ResponseEntity.ok(pacienteService.inserirPaciente(pac));
    }

    @GetMapping
    public ResponseEntity<List<Paciente>> selecionarPacientes() {
        return ResponseEntity.ok(pacienteService.selecionarPacientes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Paciente> buscarPacienteId(Integer id){
        return ResponseEntity.ok(pacienteService.buscarPacienteId(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarPaciente(@PathVariable Integer id) {
        pacienteService.excluirPaciente(id);
        return ResponseEntity.ok("Paciente excluído!");
    }

    @PutMapping
    public ResponseEntity<Paciente> atualizarPaciente(@RequestBody Paciente pac){
        return ResponseEntity.ok(pacienteService.atualizarPaciente(pac));
    }
}
