package com.dh.checkpoint2.persistance.repository;
import com.dh.checkpoint2.persistance.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Integer> {
}
