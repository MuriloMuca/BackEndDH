package com.dh.checkpoint2.controller;

import com.dh.checkPoint2.service.DentistaService;
import com.dh.checkpoint2.persistance.model.Dentista;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController @RequestMapping("dentista")
public class DentistaController {

    @Autowired
    private DentistaService dentistaService;

    @PostMapping
    public ResponseEntity<Dentista> inserirDentista(@RequestBody Dentista dent) {
            return ResponseEntity.ok(dentistaService.inserirDentista(dent));
    }

    @GetMapping
    public ResponseEntity<List<Dentista>> selecionarDentistas() {
        return ResponseEntity.ok(dentistaService.selecionarDentistas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Dentista> buscarDentistaId(Integer id) {
            return ResponseEntity.ok(dentistaService.buscarDentistaId(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarDentista(@PathVariable Integer id) {
            dentistaService.deletarDentista(id);
            return ResponseEntity.ok("Dentista de id " + id + " excluído com sucesso!");
    }

    @PutMapping
    public ResponseEntity<Dentista> atualizarDentista(@RequestBody Dentista dent) {
            return ResponseEntity.ok(dentistaService.atualizarDentista(dent));
    }
}