package com.dh.checkpoint2.service;
import com.dh.checkpoint2.persistance.model.Paciente;
import com.dh.checkpoint2.persistance.repository.PacienteRepository;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PacienteService {

    private final Logger loggerPaciente = Logger.getLogger(PacienteService.class.getName());

    @Autowired
    private PacienteRepository pacienteRepository;

    public PacienteService(){
        PropertyConfigurator.configure("log4j.properties");
    }

    public Paciente inserirPaciente(Paciente pac){
        try{
            return pacienteRepository.save(pac);
        }catch(Exception exc){
            loggerPaciente.error("Erro ao inserir novo paciente.");
            return null;
        }
    }

    public List<Paciente> selecionarPacientes(){
        try{
            return pacienteRepository.findAll();
        }catch(Exception exc){
            loggerPaciente.error("Erro ao selecionar todos os pacientes.");
            return null;
        }
    }

    public Paciente buscarPacienteId(Integer id){
        try {
            return pacienteRepository.findById(id).get();
        }catch(Exception exc){
            loggerPaciente.error("Erro ao buscar o paciente pelo id " + id);
            return null;
        }
    }

    public void excluirPaciente(Integer id){
        try{
            pacienteRepository.deleteById(id);
        } catch(Exception exc){
            loggerPaciente.error("Erro ao excluir o paciente de id" + id);
        }
    }

    public Paciente  atualizarPaciente(Paciente pac){
        try{
            Paciente paciente = pacienteRepository.getById(pac.getId());
            paciente.setNome(pac.getNome());
            paciente.setSobrenome(pac.getSobrenome());
            paciente.setEmail(pac.getEmail());

            return pacienteRepository.save(paciente);
        }catch(Exception exc){
            loggerPaciente.error("Erro ao atualizar as informações do paciente.");
            return null;
        }
    }
}
