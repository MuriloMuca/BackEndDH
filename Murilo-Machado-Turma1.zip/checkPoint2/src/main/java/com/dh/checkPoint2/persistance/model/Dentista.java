package com.dh.checkpoint2.persistance.model;

import javax.persistence.*;

@Table @Entity
public class Dentista {

    @Id
    @SequenceGenerator(name = "dentista_sequencia", sequenceName = "dentista_sequencia", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "dentista_sequencia")
    private Integer id;
    private String numeroMatricula;
    private String nome;
    private String sobrenome;

    public Dentista(String numeroMatricula, String nome, String sobrenome) {
        this.numeroMatricula = numeroMatricula;
        this.nome = nome;
        this.sobrenome = sobrenome;
    }

    public Dentista() {}

    public String getNumeroMatricula() {
        return numeroMatricula;
    }

    public String getNome() {
        return nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public Integer getId() {
        return id;
    }

    public void setNumeroMatricula(String numeroMatricula) {
        this.numeroMatricula = numeroMatricula;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }
}
