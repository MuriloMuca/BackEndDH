package com.dh.checkpoint2.persistance.repository;
import com.dh.checkpoint2.persistance.model.Dentista;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DentistaRepository extends JpaRepository<Dentista, Integer> {
}
